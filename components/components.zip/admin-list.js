const els = document.querySelectorAll(".block-close")
const blocks = document.querySelectorAll(".hidden.grid.grid-cols-1.w-full")
for (let i = 0; i < els.length; i++){
    els[i].addEventListener("click",(event) =>{
        for(let z = 0; z < blocks.length; z++){
            blocks[z].classList.add("hidden")
        }
        event.target.parentNode.parentNode.querySelector(".hidden.grid.grid-cols-1.w-full").classList.remove("hidden")
    })
}



// let isMenuShow = true
// const els = document.querySelectorAll(".block-close")
// const blocks = document.querySelectorAll(".hidden.grid.grid-cols-1.w-full")
// for (let i = 0; i < els.length; i++){
//     els[i].addEventListener("click",(event) =>{
//         if (isMenuShow ) {
//             for (let z = 0; z < blocks.length; z++) {
//                 blocks[z].classList.add("hidden")
//             }
//             event.target.parentNode.parentNode.parentNode.querySelector(".hidden.grid.grid-cols-1.w-full").classList.remove("hidden")
//             isMenuShow  = false
//         }
//         else {
//             const blocks = document.querySelectorAll(".grid.grid-cols-1.w-full")
//             for (let z = 0; z < blocks.length; z++) {
//                 blocks[z].classList.add("hidden")
//             }
//             //event.target.parentNode.parentNode.parentNode.querySelector(".grid.grid-cols-1.w-full").classList.remove("hidden")
//             isMenuShow  = true
//         }
//     })
// }