<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    use HasFactory;


    //relationship - companies with trusted phones
    public function phones() {
        return $this->hasMany(Phone::class);
    }

    //relationship - companies with contracts
    public function contracts() {
        return $this->hasMany(Contract::class);
    }

    //relationship - companies with tokens table
    public function tokens() {
        return $this->hasMany(Token::class);
    }

    //relationship - company with owner account
    public function owner() {
        return $this->belongsTo(User::class, 'user_id');
    }
}
