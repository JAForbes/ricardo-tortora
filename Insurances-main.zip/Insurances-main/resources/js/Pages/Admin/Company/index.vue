<template>
    <app-layout>
        <div class="py-6">
            <div class="max-w-7xl">
                <div class="rounded-lg bg-white px-10 py-6">
                    <div class="flex justify-end pb-6">
                        <input type="text" class="border rounded mr-8 2xl:text-base lg:text-sm md:text-xs sm:text-xxs ins-input" style="background: #FBFBFB; border-color:#B9B9C3;" placeholder="Search">
                        <inertia-link :href="route('company/create')">
                            <button class="main-bg text-white rounded 2xl:text-base lg:text-sm md:text-xs sm:text-xxs px-16 py-2">Add new</button>
                        </inertia-link>
                    </div>
                    <div class="grid grid-cols-9 rounded-lg bg-ins-2 px-1">
                        <div class="col-span-4 pl-4 py-3">
                            <p class="2xl:text-sm lg:text-sm md:text-xs sm:text-xxs uppercase main-text tracking-wider">
                                company
                            </p>
                        </div>
                        <div class="col-span-3 py-3 px-1">
                            <p class="2xl:text-sm lg:text-sm md:text-xs sm:text-xxs uppercase main-text tracking-wider">
                                Tax ID
                            </p>
                        </div>
                        <div class="col-span-2 py-3 px-1">
                            <p class="2xl:text-sm lg:text-sm md:text-xs sm:text-xxs uppercase main-text tracking-wider">
                                Country
                            </p>
                        </div>
                    </div>
                    <div class="mt-4">
                    <div class="grid grid-cols-9 rounded-lg regular-bg py-2 mb-0.5">
                        <div class="col-span-2 pl-4 flex items-center px-1">
                            <img class="2xl:w-24 xl:w-20 lg:w-16 md:w-14" :src="storage + '/images/com.png'" alt="">
                        </div>
                        <div class="col-span-2 flex items-center px-1">
                            <p class="2xl:text-base lg:text-sm md:text-xs sm:text-xxs main-text">
                                PromTransInvest
                            </p>
                        </div>
                        <div class="col-span-3 flex items-center px-1">
                            <p class="2xl:text-base lg:text-sm md:text-xs sm:text-xxs main-text">
                                474767676248765856287
                            </p>
                        </div>
                        <div class="col-span-2 flex items-center px-1">
                            <p class="2xl:text-base lg:text-sm md:text-xs sm:text-xxs main-text">
                                Italy
                            </p>
                        </div>
                    </div>
                        <div class="grid grid-cols-9 rounded-lg regular-bg py-2 mb-0.5">
                            <div class="col-span-2 pl-4 flex items-center px-1">
                                <img class="2xl:w-24 xl:w-20 lg:w-16 md:w-14" :src="storage + '/images/com.png'" alt="">
                            </div>
                            <div class="col-span-2 flex items-center px-1">
                                <p class="2xl:text-base lg:text-sm md:text-xs sm:text-xxs main-text">
                                    PromTransInvest
                                </p>
                            </div>
                            <div class="col-span-3 flex items-center px-1">
                                <p class="2xl:text-base lg:text-sm md:text-xs sm:text-xxs main-text">
                                    474767676248765856287
                                </p>
                            </div>
                            <div class="col-span-2 flex items-center px-1">
                                <p class="2xl:text-base lg:text-sm md:text-xs sm:text-xxs main-text">
                                    Italy
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </app-layout>
</template>

<script>
    import AppLayout from '@/Layouts/AppLayout'
    export default {
        components: {
            AppLayout,
        },
        data: function () {
            return {
                storage: window.location.origin,
            }
        }
    }
</script>

<style scoped>

</style>