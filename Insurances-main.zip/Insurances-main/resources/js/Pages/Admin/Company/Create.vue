<template>
    <app-layout>
        <div class="py-6">
            <div class="max-w-7xl">

            </div>
        </div>
    </app-layout>
</template>

<script>
    import AppLayout from '@/Layouts/AppLayout'

    export default {
        name: "Create",
        components: {
            AppLayout,
        },
    }
</script>

<style scoped>

</style>