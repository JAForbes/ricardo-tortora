<template>
    <section class="containerc relative">
        <!--Background image-->
        <div class="block-image">
            <img class="bg-image" src="images/bg1.jpg" alt="">
            <div class="logo">
                <img src="images/logo.png">
                <p class="logo-title">POLIZZACERTA </p>
            </div>
        </div>
        <!--Contract search form-->
        <div class="block-form">
            <div class="registration-form">
                <p class="form-title">Verify your policy</p>
                <p class="form-subtitle">How does it work? <span class="red">Discover PolizzaCerta</span></p>

                <div class="form-div">
                    <span class="form-label">Choose the Insurance Company</span>
                    <p class="select">
                        <!--Company select-->
                        <select class="form-input" name="select2" v-model="company">
                            <!--                    <option selected="selected">Insurance Company</option>-->
                            <option value="1">Insurance Company</option>
                            <option value="2">Insurance Company 1</option>
                            <option value="3">Insurance Company 2</option>
                            <option value="4">Insurance Company 3</option>
                            <option value="5">Insurance Company 4</option>
                        </select></p>
                    <p><span class="form-label">The policy number</span> <span class="blue">Where I can find a Policy Number?</span>
                    </p>
                    <!--Policy Number input field-->
                    <input class="form-input" type="text" id="policy" placeholder="Policy number">
                    <span class="form-label">Tax identification Number</span>
                    <!--Tax number input field-->
                    <input class="form-input eye-off" type="password" id="tax" placeholder="Tax identification number">
                    <p class="form-subtitle red right">Is my data safe?</p>
                    <button class="form-button" @click="search">Check Policy</button>
                </div>
            </div>
        </div>
        <!--Not found modal-->
        <div class="form-alert absolute fade-in" v-if="status && !type">
            <div class="form-block relative flex items-end justify-center">
                <div class="absolute top-4 right-4 cursor-pointer" @click="closeSearch">
                    <svg width="50" height="50" viewBox="0 0 50 50" fill="#B9B9C3" xmlns="http://www.w3.org/2000/svg">
                        <path d="M38.9596 36.042C39.793 36.8753 39.793 38.1253 38.9596 38.9587C38.543 39.3753 38.1263 39.5837 37.5013 39.5837C36.8763 39.5837 36.4596 39.3753 36.043 38.9587L25.0013 27.917L13.9596 38.9587C13.543 39.3753 13.1263 39.5837 12.5013 39.5837C11.8763 39.5837 11.4596 39.3753 11.043 38.9587C10.2096 38.1253 10.2096 36.8753 11.043 36.042L22.0846 25.0003L11.043 13.9587C10.2096 13.1253 10.2096 11.8753 11.043 11.042C11.8763 10.2087 13.1263 10.2087 13.9596 11.042L25.0013 22.0837L36.043 11.042C36.8763 10.2087 38.1263 10.2087 38.9596 11.042C39.793 11.8753 39.793 13.1253 38.9596 13.9587L27.918 25.0003L38.9596 36.042Z"
                              fill="#B9B9C3"/>
                        <mask mask-type="alpha" maskUnits="userSpaceOnUse" x="10" y="10" width="30" height="30">
                            <path d="M38.9596 36.042C39.793 36.8753 39.793 38.1253 38.9596 38.9587C38.543 39.3753 38.1263 39.5837 37.5013 39.5837C36.8763 39.5837 36.4596 39.3753 36.043 38.9587L25.0013 27.917L13.9596 38.9587C13.543 39.3753 13.1263 39.5837 12.5013 39.5837C11.8763 39.5837 11.4596 39.3753 11.043 38.9587C10.2096 38.1253 10.2096 36.8753 11.043 36.042L22.0846 25.0003L11.043 13.9587C10.2096 13.1253 10.2096 11.8753 11.043 11.042C11.8763 10.2087 13.1263 10.2087 13.9596 11.042L25.0013 22.0837L36.043 11.042C36.8763 10.2087 38.1263 10.2087 38.9596 11.042C39.793 11.8753 39.793 13.1253 38.9596 13.9587L27.918 25.0003L38.9596 36.042Z"
                                  fill="white"/>
                        </mask>
                    </svg>
                </div>
                <div class="icon-block icon-fail absolute flex items-center justify-center">
                    <svg class="alert-logo" viewBox="0 0 106 106" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                              d="M9.25094 94.9995C11.4384 96.312 13.6259 96.7495 15.8134 96.7495H90.1884C93.6884 96.7495 96.7509 95.437 98.9384 92.812C101.563 90.6245 102.876 87.1245 102.876 83.6245C102.876 81.437 102.438 79.2495 101.126 77.062L64.3759 15.3745C62.1884 12.312 59.5634 10.1245 56.0634 9.24949C52.5634 8.37449 49.0634 8.81199 46.0009 10.562C44.2509 11.437 42.5009 13.187 41.6259 14.937L4.43844 77.062C0.938435 83.187 3.12594 91.4995 9.25094 94.9995ZM12.3133 81.4368L49.0633 19.7493C49.5008 18.8743 49.9383 18.4368 50.8133 17.9993C53.0008 17.1243 55.6258 17.5618 56.9383 19.7493L93.6883 81.4368C94.1258 82.3118 94.1258 82.7493 94.1258 83.6243C94.1258 84.9368 93.6883 85.8118 92.8133 86.6868C91.9383 87.5618 91.0633 87.9993 89.7508 87.9993H15.8133C15.3758 87.9993 14.5008 87.9993 14.0633 87.5618C11.8758 86.2493 11.0008 83.6243 12.3133 81.4368ZM57.3751 57.375V39.875C57.3751 37.25 55.6251 35.5 53.0001 35.5C50.3751 35.5 48.6251 37.25 48.6251 39.875V57.375C48.6251 60 50.3751 61.75 53.0001 61.75C55.6251 61.75 57.3751 60 57.3751 57.375ZM57.3757 74.875C57.3757 76.1875 56.9382 77.0625 56.0632 77.9375C55.1882 78.8125 54.3132 79.25 52.5632 79.25C51.2507 79.25 50.3757 78.8125 49.5007 77.9375C48.6257 77.0625 48.1882 76.1875 48.1882 74.875C48.1882 74.3624 48.3383 74 48.4627 73.6998C48.5506 73.4874 48.6257 73.3062 48.6257 73.125C48.6257 72.6875 49.0632 72.25 49.5007 71.8125C49.9382 71.375 50.3757 70.9375 50.8132 70.9375C51.6882 70.5 52.5632 70.5 53.4382 70.5C53.6898 70.7516 53.7967 70.8585 53.9253 70.9039C54.0204 70.9375 54.1273 70.9375 54.3132 70.9375C54.5319 70.9375 54.6413 71.0469 54.7507 71.1562C54.8601 71.2656 54.9694 71.375 55.1882 71.375C55.6257 71.375 56.0632 71.8125 56.0632 71.8125C56.5007 72.25 56.9382 72.6875 56.9382 73.125C57.3757 73.5625 57.3757 74.4375 57.3757 74.875Z"
                              fill="white"/>
                        <mask id="mask0" mask-type="alpha" maskUnits="userSpaceOnUse" x="2" y="8" width="101"
                              height="89">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                  d="M9.25094 94.9995C11.4384 96.312 13.6259 96.7495 15.8134 96.7495H90.1884C93.6884 96.7495 96.7509 95.437 98.9384 92.812C101.563 90.6245 102.876 87.1245 102.876 83.6245C102.876 81.437 102.438 79.2495 101.126 77.062L64.3759 15.3745C62.1884 12.312 59.5634 10.1245 56.0634 9.24949C52.5634 8.37449 49.0634 8.81199 46.0009 10.562C44.2509 11.437 42.5009 13.187 41.6259 14.937L4.43844 77.062C0.938435 83.187 3.12594 91.4995 9.25094 94.9995ZM12.3133 81.4368L49.0633 19.7493C49.5008 18.8743 49.9383 18.4368 50.8133 17.9993C53.0008 17.1243 55.6258 17.5618 56.9383 19.7493L93.6883 81.4368C94.1258 82.3118 94.1258 82.7493 94.1258 83.6243C94.1258 84.9368 93.6883 85.8118 92.8133 86.6868C91.9383 87.5618 91.0633 87.9993 89.7508 87.9993H15.8133C15.3758 87.9993 14.5008 87.9993 14.0633 87.5618C11.8758 86.2493 11.0008 83.6243 12.3133 81.4368ZM57.3751 57.375V39.875C57.3751 37.25 55.6251 35.5 53.0001 35.5C50.3751 35.5 48.6251 37.25 48.6251 39.875V57.375C48.6251 60 50.3751 61.75 53.0001 61.75C55.6251 61.75 57.3751 60 57.3751 57.375ZM57.3757 74.875C57.3757 76.1875 56.9382 77.0625 56.0632 77.9375C55.1882 78.8125 54.3132 79.25 52.5632 79.25C51.2507 79.25 50.3757 78.8125 49.5007 77.9375C48.6257 77.0625 48.1882 76.1875 48.1882 74.875C48.1882 74.3624 48.3383 74 48.4627 73.6998C48.5506 73.4874 48.6257 73.3062 48.6257 73.125C48.6257 72.6875 49.0632 72.25 49.5007 71.8125C49.9382 71.375 50.3757 70.9375 50.8132 70.9375C51.6882 70.5 52.5632 70.5 53.4382 70.5C53.6898 70.7516 53.7967 70.8585 53.9253 70.9039C54.0204 70.9375 54.1273 70.9375 54.3132 70.9375C54.5319 70.9375 54.6413 71.0469 54.7507 71.1562C54.8601 71.2656 54.9694 71.375 55.1882 71.375C55.6257 71.375 56.0632 71.8125 56.0632 71.8125C56.5007 72.25 56.9382 72.6875 56.9382 73.125C57.3757 73.5625 57.3757 74.4375 57.3757 74.875Z"
                                  fill="white"/>
                        </mask>
                        <g mask="url(#mask0)">
                            <rect x="0.5" y="0.5" width="105" height="105" fill="white"/>
                        </g>
                    </svg>
                </div>
                <div class="2xl:pb-20 xl:pb-16 pb-8 w-10/12 text-center">
                    <p class="form-title font-bold" style="color:#5E5873;">
                        Policy not found
                    </p>
                    <p class="form-subtitle pt-3" style="color: #5E5873; font-weight: 300;">
                        The policy no. <strong class="font-bold">ABC-123456789</strong> <br>with the Tax ID ABC-12358CC
                        is not validated.
                    </p>
                    <p class="form-subtitle 2xl:pt-8 xl:pt-5 text-left sm:mb-1 xl:mb-0"
                       style="color: #5E5873; font-weight: 300;">
                        1) Check if the policy no. inserted is correct clicking here
                    </p>
                    <p class="form-subtitle text-left sm:mb-1 xl:mb-0" style="color: #5E5873; font-weight: 300;">
                        2) Check if the Tax ID is the same of the insurance contract
                    </p>
                    <p class="form-subtitle text-left sm:mb-1 xl:mb-0" style="color: #5E5873; font-weight: 300;">
                        3) Check if the contract show the certified logo (show logo)
                    </p>
                    <p class="form-subtitle text-left sm:mb-1 xl:mb-0" style="color: #5E5873; font-weight: 300;">
                        4) If you still have doubts, please contact us via chat <br>
                    </p>
                </div>
            </div>
        </div>
        <!--Success search modal-->
        <div class="form-alert absolute fade-in" v-if="status && type">
            <div class="form-block relative flex items-end justify-center">
                <div class="absolute top-4 right-4 cursor-pointer" @click="closeSearch">
                    <svg width="50" height="50" viewBox="0 0 50 50" fill="#B9B9C3" xmlns="http://www.w3.org/2000/svg">
                        <path d="M38.9596 36.042C39.793 36.8753 39.793 38.1253 38.9596 38.9587C38.543 39.3753 38.1263 39.5837 37.5013 39.5837C36.8763 39.5837 36.4596 39.3753 36.043 38.9587L25.0013 27.917L13.9596 38.9587C13.543 39.3753 13.1263 39.5837 12.5013 39.5837C11.8763 39.5837 11.4596 39.3753 11.043 38.9587C10.2096 38.1253 10.2096 36.8753 11.043 36.042L22.0846 25.0003L11.043 13.9587C10.2096 13.1253 10.2096 11.8753 11.043 11.042C11.8763 10.2087 13.1263 10.2087 13.9596 11.042L25.0013 22.0837L36.043 11.042C36.8763 10.2087 38.1263 10.2087 38.9596 11.042C39.793 11.8753 39.793 13.1253 38.9596 13.9587L27.918 25.0003L38.9596 36.042Z"
                              fill="#B9B9C3"/>
                        <mask mask-type="alpha" maskUnits="userSpaceOnUse" x="10" y="10" width="30" height="30">
                            <path d="M38.9596 36.042C39.793 36.8753 39.793 38.1253 38.9596 38.9587C38.543 39.3753 38.1263 39.5837 37.5013 39.5837C36.8763 39.5837 36.4596 39.3753 36.043 38.9587L25.0013 27.917L13.9596 38.9587C13.543 39.3753 13.1263 39.5837 12.5013 39.5837C11.8763 39.5837 11.4596 39.3753 11.043 38.9587C10.2096 38.1253 10.2096 36.8753 11.043 36.042L22.0846 25.0003L11.043 13.9587C10.2096 13.1253 10.2096 11.8753 11.043 11.042C11.8763 10.2087 13.1263 10.2087 13.9596 11.042L25.0013 22.0837L36.043 11.042C36.8763 10.2087 38.1263 10.2087 38.9596 11.042C39.793 11.8753 39.793 13.1253 38.9596 13.9587L27.918 25.0003L38.9596 36.042Z"
                                  fill="white"/>
                        </mask>
                    </svg>
                </div>
                <div class="icon-block icon-success absolute flex items-center justify-center">
                    <svg class="alert-logo" viewBox="0 0 89 88" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                              d="M73.8351 29.2724C73.8351 13.1726 60.6351 0 44.5018 0C28.3685 0 15.1685 13.1726 15.1685 29.2724C15.1685 38.7859 19.5685 47.2017 26.5351 52.3243L22.5018 83.7921C22.1351 85.2557 22.8685 86.7193 23.9685 87.4511C25.0685 88.183 26.5351 88.183 28.0018 87.4511L44.5018 77.5717L61.0018 87.4511C61.3685 87.817 62.1018 87.817 62.8351 87.817C63.5685 87.817 64.3018 87.4511 64.6685 87.0852C65.7685 86.3534 66.5018 84.8898 66.1351 83.4262L62.1018 52.3243C69.4351 47.2017 73.8351 38.7859 73.8351 29.2724ZM22.502 29.2724C22.502 17.1976 32.402 7.31816 44.502 7.31816C56.602 7.31816 66.502 17.1976 66.502 29.2724C66.502 41.3473 56.602 51.2267 44.502 51.2267C32.402 51.2267 22.502 41.3473 22.502 29.2724ZM46.3351 70.2534L58.0684 77.2056L55.5017 56.349C52.2017 57.8127 48.5351 58.5445 44.5017 58.5445C40.4684 58.5445 36.8017 57.8127 33.5017 56.349L30.9351 77.2056L42.6684 70.2534C43.7684 69.5216 45.2351 69.5216 46.3351 70.2534Z"
                              fill="black"/>
                        <mask id="mask0" mask-type="alpha" maskUnits="userSpaceOnUse" x="15" y="0" width="59"
                              height="88">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                  d="M73.8351 29.2724C73.8351 13.1726 60.6351 0 44.5018 0C28.3685 0 15.1685 13.1726 15.1685 29.2724C15.1685 38.7859 19.5685 47.2017 26.5351 52.3243L22.5018 83.7921C22.1351 85.2557 22.8685 86.7193 23.9685 87.4511C25.0685 88.183 26.5351 88.183 28.0018 87.4511L44.5018 77.5717L61.0018 87.4511C61.3685 87.817 62.1018 87.817 62.8351 87.817C63.5685 87.817 64.3018 87.4511 64.6685 87.0852C65.7685 86.3534 66.5018 84.8898 66.1351 83.4262L62.1018 52.3243C69.4351 47.2017 73.8351 38.7859 73.8351 29.2724ZM22.502 29.2724C22.502 17.1976 32.402 7.31816 44.502 7.31816C56.602 7.31816 66.502 17.1976 66.502 29.2724C66.502 41.3473 56.602 51.2267 44.502 51.2267C32.402 51.2267 22.502 41.3473 22.502 29.2724ZM46.3351 70.2534L58.0684 77.2056L55.5017 56.349C52.2017 57.8127 48.5351 58.5445 44.5017 58.5445C40.4684 58.5445 36.8017 57.8127 33.5017 56.349L30.9351 77.2056L42.6684 70.2534C43.7684 69.5216 45.2351 69.5216 46.3351 70.2534Z"
                                  fill="white"/>
                        </mask>
                        <g mask="url(#mask0)">
                            <rect x="0.500977" width="88" height="88" fill="white"/>
                        </g>
                    </svg>


                </div>
                <div class="2xl:pb-20 xl:pb-16 pb-8 w-10/12 text-center">
                    <p class="form-title font-bold" style="color:#5E5873;">
                        Policy Certified
                    </p>
                    <p class="form-subtitle pt-3" style="color: #5E5873; font-weight: 400;">
                        The policy no. <strong class="font-bold">ABC-123456789</strong> referring to the Tax ID<br>
                        ABC-12358CC is certified.
                    </p>
                    <div class="flex mt-8">
                        <img class="success-icon" src="images/done.png" alt="">
                        <div>
                            <p class="success-text montserrat text-left ml-2 mb-2" style="font-weight: 500;">
                                Insurance company
                            </p>
                            <p class="success-text montserrat text-left ml-2 mb-2" style="font-weight: 400;">
                                Imkliva
                            </p>
                        </div>
                    </div>
                    <div class="flex mt-5">
                        <img class="success-icon" src="images/calendar.png" alt="">
                        <div>
                            <p class="success-text montserrat text-left ml-2 mb-2" style="font-weight: 500;">
                                Expiration date
                            </p>
                            <p class="success-text montserrat text-left ml-2 mb-2" style="font-weight: 400;">
                                21 Jan 2022
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--background color block-->
        <div class="alert-flag absolute fade-in" v-if="status" v-bind:class="{'fail':!type, 'success': type}"></div>
        <div class="backdrop absolute" v-if="status"></div>
    </section>
</template>

<script>
    export default {
        props: {
            canLogin: Boolean,
            canRegister: Boolean,
            laravelVersion: String,
            phpVersion: String,
        },
        data: function () {
            return {
                status: false,
                type: false,
                company: 1,
            }
        },
        methods: {
            //search function
            search: function () {
                if (this.company == 1) {
                    this.type = true;
                }
                else {
                    this.type = false;
                }
                this.status = true;
            },
            //close modal function
            closeSearch: function () {
                this.status = false;
            }
        }
    }
</script>
<style scoped>
    .form-alert {
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 100;
    }

    .form-alert .form-block {
        width: 800px;
        height: 630px;
        background: #F7F7F7;
        border-radius: 12px;
    }

    .alert-flag {
        top: 50%;
        left: 50%;
        transform: translate(-50%, -18.5%);
        z-index: 75;
        width: 650px;
        height: 450px;
        border-radius: 20px;
    }

    .alert-flag.fail {
        background: linear-gradient(85.65deg, #FF7272 19.65%, #FFD295 111.26%);
    }

    .alert-flag.success {
        background: linear-gradient(82.01deg, #00BE6A 18.04%, #A2EBA1 102.83%);
    }

    .alert-logo {
        width: 106px;
        height: 106px;
    }

    .icon-block {
        top: 0%;
        left: 50%;
        transform: translate(-50%, -40%);
        width: 220px;
        height: 220px;
        border-radius: 50%;
        z-index: 100;
        box-shadow: 0px 5.54276px 33.2565px rgba(0, 0, 0, 0.06);
    }

    .icon-fail {
        background: linear-gradient(85.65deg, #FF7272 19.65%, #FFD295 111.26%);
        filter: drop-shadow(0px 10px 100px rgba(255, 114, 114, 0.4));
    }

    .icon-success {
        background: linear-gradient(82.01deg, #00BE6A 18.04%, #A2EBA1 102.83%);
        filter: drop-shadow(0px 10px 100px rgba(0, 190, 106, 0.4));
    }

    .success-icon {
        width: 65px;
        height: 65px;
    }

    .success-text {
        font-size: 20px;
        line-height: 21px;
        color: #5E5873;
    }

    .backdrop {
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: #000000;
        opacity: 0.5;
        z-index: 50;
    }

    .containerc {
        background: #fff;
        width: 100vw;
        height: 100vh;
        overflow: hidden;
        display: grid;
        grid-template-columns: 1fr 1fr;
    }

    .bg-image {
        z-index: 0;
        position: relative;
        object-fit: cover;
        object-fit: cover;
        width: 100%;
        height: 100%;
    }

    .logo {
        z-index: 1;
        position: absolute;
        left: 15.62%;

        top: 8.89%;

        display: flex;
        flex-direction: row;
        flex-wrap: nowrap;
        align-items: center;
    }

    .logo-title {
        margin-left: 16px;
        font-family: Circular Std;
        font-style: normal;
        font-weight: normal;
        font-size: 30px;
        line-height: 38px;
        letter-spacing: -0.428571px;
        color: #FFFFFF;
    }

    .registration-form {
        position: absolute;
        top: 40%;
        transform: translateY(-40%);
        z-index: 2;
        width: 95%;
        max-width: 650px;
        /* height: 100%; */
        max-height: 99%;
        /* margin: 10%; */
        background: #FFFFFF;
        border-radius: 16px;
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: flex-start;
        padding: 36px 36px;
    }

    .block-image {

        grid-column: 1/3;
        grid-row: 1/2;
    }

    .block-form {
        position: relative;
        /*height: 100vh;*/
        /*height: 85%;*/
        grid-row: 1/2;
        grid-column: 2/2;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    .form-div {
        width: 100%;
        margin-top: 24px;
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: flex-start;
    }

    .form-title {
        font-family: Circular Std;
        font-style: normal;
        font-weight: bold;
        font-size: 40px;
        line-height: 51px;
        letter-spacing: -0.428571px;
        color: #152232;
    }

    .form-subtitle {
        margin-top: 16px;
        font-family: Circular Std;
        font-style: normal;
        font-weight: bold;
        font-size: 24px;
        line-height: 30px;
        letter-spacing: -0.428571px;
        color: #949CA5;
    }

    .form-label {
        margin: 0 0 16px 0;
        font-family: Circular Std;
        font-style: normal;
        font-weight: bold;
        font-size: 20px;
        line-height: 21px;
        letter-spacing: -0.428571px;
        color: #152232;
    }

    ::-webkit-input-placeholder { /* Chrome */
        font-family: Circular Std;
        font-style: normal;
        font-weight: normal;
        font-size: 20px;
        line-height: 25px;
        letter-spacing: -0.428571px;
        color: #D8D6DE;
    }

    :-ms-input-placeholder { /* IE 10+ */
        font-family: Circular Std;
        font-style: normal;
        font-weight: normal;
        font-size: 20px;
        line-height: 25px;
        letter-spacing: -0.428571px;
        color: #D8D6DE;
    }

    ::-moz-placeholder { /* Firefox 19+ */
        font-family: Circular Std;
        font-style: normal;
        font-weight: normal;
        font-size: 20px;
        line-height: 25px;
        letter-spacing: -0.428571px;
        color: #D8D6DE;
    }

    :-moz-placeholder { /* Firefox 4 - 18 */
        font-family: Circular Std;
        font-style: normal;
        font-weight: normal;
        font-size: 20px;
        line-height: 25px;
        letter-spacing: -0.428571px;
        color: #D8D6DE;
    }

    select.form-input {
        font-family: Circular Std;
        font-style: normal;
        font-weight: normal;
        font-size: 20px;
        line-height: 25px;
        letter-spacing: -0.428571px;
        color: #6E6B7B;
    }

    select option {
        color: #6E6B7B;
    }

    .select {
        position: relative;
        min-width: 100%;

    }

    .select select {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
    }

    .select:after {
        content: "";
        display: block;
        border-style: solid;
        border-width: 13px 9px 0 9px;
        border-color: #000 transparent transparent transparent;
        pointer-events: none;
        position: absolute;
        top: 50%;
        right: 1rem;
        z-index: 1;
        margin-top: -16px;
    }

    .form-input {
        margin-bottom: 24px;
        width: 100%;
        height: 80px;
        outline: none;
        padding: 28px 13px;
        background: #FFFFFF;
        border: 1px solid #D8D6DE;
        border-radius: 8px;
        font-family: Circular Std;
        font-style: normal;
        font-weight: normal;
        font-size: 20px;
        line-height: 25px;
        letter-spacing: -0.428571px;
        color: #3d3b44;
    }

    .eye-off::after {
        content: "555555";

    }

    /*.form-div p {*/
    /*margin-bottom: 14px;*/
    /*}*/

    input[name='company'] {
        width: 100%;
        min-width: 400px;
    }

    .red {
        color: #E6967A;
    }

    .blue {
        color: #4881EF;
    }

    .right {
        align-self: flex-end;
    }

    .form-button {
        cursor: pointer;
        border: 1px solid #91D690;
        margin-top: 38px;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        /*padding: 35px 180px;*/
        width: 100%;
        height: 85px;
        max-height: 100%;
        background: #91D690;
        border-radius: 10px;
        font-family: Circular Std;
        font-style: normal;
        font-weight: normal;
        font-size: 24px;
        line-height: 30px;
        text-align: center;
        letter-spacing: -0.428571px;
        color: #FFFFFF;
        transition: background .3s linear;
    }

    .form-button:hover {
        background: #fff;
        color: #91D690;
    }

    span {
        font-family: Circular Std;
        font-style: normal;
        font-weight: bold;
        font-size: 20px;
        line-height: 25px;
        letter-spacing: -0.428571px;

        color: #152232;
    }

    p.form-subtitle.red.right {
        margin-top: -18px;
    }

    @media screen and (max-width: 1640px) {
        .form-alert .form-block {
            width: 650px;
            height: 540px;
            background: #F7F7F7;
            border-radius: 12px;
        }

        .icon-block {
            top: 0%;
            left: 50%;
            transform: translate(-50%, -40%);
            width: 180px;
            height: 180px;
            border-radius: 50%;
            z-index: 100;
        }

        .alert-flag {
            top: 50%;
            left: 50%;
            transform: translate(-50%, -22.5%);
            z-index: 75;
            width: 550px;
            height: 400px;
            background: linear-gradient(85.65deg, #FF7272 19.65%, #FFD295 111.26%);
            border-radius: 20px;
        }

        .alert-logo {
            width: 86px;
            height: 86px;
        }

        .success-icon {
            width: 60px;
            height: 60px;
        }

        .success-text {
            font-size: 18px;
            line-height: 20px;
            color: #5E5873;
        }

        .registration-form {
            top: 35%;
            padding: 32px 32px;
        }

        span {
            font-size: 16px;
            line-height: 21px;
        }

        .form-input {
            height: 60px;
            padding: 15px 13px;
            font-size: 16px;
            line-height: 21px;
        }

        .form-title {
            font-size: 36px;
            line-height: 41px;
        }

        .form-subtitle {
            font-size: 20px;
            line-height: 25px;
        }

        .form-label {
            font-size: 16px;
            line-height: 25px;
        }

        .form-button {
            margin-top: 27px;
            height: 75px;
            font-size: 20px;
            line-height: 25px;
        }

        select.form-input {
            font-size: 16px;
            line-height: 21px;
        }

        ::-webkit-input-placeholder { /* Chrome */
            font-size: 16px;
            line-height: 21px;
        }

        :-ms-input-placeholder { /* IE 10+ */
            font-size: 16px;
            line-height: 21px;
        }

        ::-moz-placeholder { /* Firefox 19+ */
            font-size: 16px;
            line-height: 21px;
        }

        :-moz-placeholder { /* Firefox 4 - 18 */
            font-size: 16px;
            line-height: 21px;
        }
    }

    @media screen and (max-width: 1400px) {
        .form-alert .form-block {
            width: 650px;
            height: 540px;
            background: #F7F7F7;
            border-radius: 12px;
        }

        .icon-block {
            top: 0%;
            left: 50%;
            transform: translate(-50%, -40%);
            width: 180px;
            height: 180px;
            border-radius: 50%;
            z-index: 100;
        }

        .alert-flag {
            top: 50%;
            left: 50%;
            transform: translate(-50%, -24.5%);
            z-index: 75;
            width: 530px;
            height: 330px;
            background: linear-gradient(85.65deg, #FF7272 19.65%, #FFD295 111.26%);
            border-radius: 20px;
        }

        .alert-logo {
            width: 66px;
            height: 66px;
        }

        .icon-block {
            top: 0%;
            left: 50%;
            transform: translate(-50%, -40%);
            width: 160px;
            height: 160px;
            border-radius: 50%;
            z-index: 100;
        }

        .registration-form {
            top: 33%;
            width: 80%;
            padding: 26px 26px;
        }

        span {
            font-size: 14px;
            line-height: 18px;
        }

        .form-input {
            height: 55px;
            padding: 13px 11px;
            font-size: 14px;
            line-height: 18px;
        }

        .form-title {
            font-size: 34px;
            line-height: 38px;
        }

        .form-subtitle {
            font-size: 18px;
            line-height: 22px;
        }

        .form-label {
            font-size: 14px;
            line-height: 22px;
            margin: 0 0 6px 0;
        }

        .form-button {
            margin-top: 25px;
            height: 70px;
            font-size: 18px;
            line-height: 22px;
        }

        select.form-input {
            font-size: 14px;
            line-height: 18px;
        }

        ::-webkit-input-placeholder { /* Chrome */
            font-size: 14px;
            line-height: 18px;
        }

        :-ms-input-placeholder { /* IE 10+ */
            font-size: 14px;
            line-height: 18px;
        }

        ::-moz-placeholder { /* Firefox 19+ */
            font-size: 14px;
            line-height: 18px;
        }

        :-moz-placeholder { /* Firefox 4 - 18 */
            font-size: 14px;
            line-height: 18px;
        }
    }

    @media screen and (min-width: 1922px) {
        .registration-form {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
        }
    }

    @media screen and (min-width: 1800px) {
        .bg-image {
            margin-top: -70px;
        }
    }

    @media screen and (max-width: 1200px) {
        .registration-form {
            padding: 26px;
            width: 120%;
            margin-left: -21%;
        }

        .form-button {
            margin-top: 0;
        }

        .logo {
            left: 5%;
        }

    }

    @media screen and (max-width: 1024px) {
        .registration-form {
            width: 120%;
            margin-left: -28%;
        }

        .logo {
            left: 1.6%;
        }

    }

    @media screen and (max-width: 768px) {
        .form-alert .form-block {
            width: 350px;
            height: 470px;
            background: #F7F7F7;
            border-radius: 12px;
        }

        .icon-block {
            top: 0%;
            left: 50%;
            transform: translate(-50%, -40%);
            width: 100px;
            height: 100px;
            border-radius: 50%;
            z-index: 100;
        }

        .alert-flag {
            top: 50%;
            left: 50%;
            transform: translate(-50%, 40%);
            z-index: 75;
            width: 296px;
            height: 183px;
            background: linear-gradient(85.65deg, #FF7272 19.65%, #FFD295 111.26%);
            border-radius: 20px;
        }

        .alert-logo {
            width: 48px;
            height: 48px;
        }

        .success-icon {
            width: 50px;
            height: 50px;
        }

        .success-text {
            font-size: 16px;
            line-height: 18px;
            color: #5E5873;
        }

        .logo img {
            width: 25px;
        }

        .registration-form {
            position: relative;
            width: 100%;
            padding: 15px;
            margin-left: 0;
        }

        .container {
            grid-template-columns: 1fr;
            width: 100%;
            height: 100%;
        }

        .bg-image {
            grid-row: 1/2;
            grid-column: 1/3;
        }

        .block-form {
            height: 100%;
            grid-row: 2/3;
            grid-column: 1/3;
        }

        .logo {
            left: 50%;
        }

        .logo-title {
            font-size: 20px;
        }

        .form-title {
            font-size: 24px;
        }

        .form-label {
            display: none;
        }

        .form-subtitle, .form-label span {
            font-size: 16px;
            display: block;
        }

        .form-input {
            margin-bottom: 24px;

        }

        .right {
            align-self: flex-start;
            font-size: 16px;
        }

        p.form-subtitle.red.right {
            margin-top: -15px;
        }

        .form-button {
            margin-top: 30px;
        }
    }

    @media (max-width: 388px) {
        .logo {
            top: 3%;
        }

        .logo-title {
            font-size: 14px;
        }
    }

    /*.bg-gray-100 {*/
    /*background-color: #f7fafc;*/
    /*background-color: rgba(247, 250, 252, var(--tw-bg-opacity));*/
    /*}*/

    /*.border-gray-200 {*/
    /*border-color: #edf2f7;*/
    /*border-color: rgba(237, 242, 247, var(--tw-border-opacity));*/
    /*}*/

    /*.text-gray-400 {*/
    /*color: #cbd5e0;*/
    /*color: rgba(203, 213, 224, var(--tw-text-opacity));*/
    /*}*/

    /*.text-gray-500 {*/
    /*color: #a0aec0;*/
    /*color: rgba(160, 174, 192, var(--tw-text-opacity));*/
    /*}*/

    /*.text-gray-600 {*/
    /*color: #718096;*/
    /*color: rgba(113, 128, 150, var(--tw-text-opacity));*/
    /*}*/

    /*.text-gray-700 {*/
    /*color: #4a5568;*/
    /*color: rgba(74, 85, 104, var(--tw-text-opacity));*/
    /*}*/

    /*.text-gray-900 {*/
    /*color: #1a202c;*/
    /*color: rgba(26, 32, 44, var(--tw-text-opacity));*/
    /*}*/

    /*@media (prefers-color-scheme: dark) {*/
    /*.dark\:bg-gray-800 {*/
    /*background-color: #2d3748;*/
    /*background-color: rgba(45, 55, 72, var(--tw-bg-opacity));*/
    /*}*/

    /*.dark\:bg-gray-900 {*/
    /*background-color: #1a202c;*/
    /*background-color: rgba(26, 32, 44, var(--tw-bg-opacity));*/
    /*}*/

    /*.dark\:border-gray-700 {*/
    /*border-color: #4a5568;*/
    /*border-color: rgba(74, 85, 104, var(--tw-border-opacity));*/
    /*}*/

    /*.dark\:text-white {*/
    /*color: #fff;*/
    /*color: rgba(255, 255, 255, var(--tw-text-opacity));*/
    /*}*/

    /*.dark\:text-gray-400 {*/
    /*color: #cbd5e0;*/
    /*color: rgba(203, 213, 224, var(--tw-text-opacity));*/
    /*}*/
    /*}*/
</style>

