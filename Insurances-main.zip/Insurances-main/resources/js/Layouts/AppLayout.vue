<template>
    <div>
        <!--<jet-banner />-->

        <div class="min-h-screen bg-gray-100">
            <div class="grid grid-cols-4 min-h-screen">
                <div class="bg-ins-2 p-8 sticky top-0 h-full">
                    <div class="flex-shrink-0 mt-3 flex items-center">
                        <inertia-link :href="route('dashboard')">
                            <jet-application-mark class="block h-9 w-auto" />
                        </inertia-link>
                    </div>
                        <div class="mt-16">
                    <div class="bg-white rounded-lg flex items-center py-3 px-4 mt-3">
                        <svg class="menu-icon" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M27 10.271L15.75 1.53093C15.25 1.15636 14.625 1.15636 14.25 1.53093L3 10.271C2.625 10.5207 2.5 10.8953 2.5 11.2699V25.0043C2.5 27.1268 4.125 28.75 6.25 28.75H23.75C25.875 28.75 27.5 27.1268 27.5 25.0043V11.2699C27.5 10.8953 27.375 10.5207 27 10.271ZM17.5 16.2642V26.2528H12.5V16.2642H17.5ZM23.75 26.2528C24.5 26.2528 25 25.7534 25 25.0043V11.8942L15 4.15295L5 11.8942V25.0043C5 25.7534 5.5 26.2528 6.25 26.2528H10V15.0156C10 14.2665 10.5 13.767 11.25 13.767H18.75C19.5 13.767 20 14.2665 20 15.0156V26.2528H23.75Z" fill="#5E5873"/>
                            <mask id="mask0" mask-type="alpha" maskUnits="userSpaceOnUse" x="2" y="1" width="26" height="28">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M27 10.271L15.75 1.53093C15.25 1.15636 14.625 1.15636 14.25 1.53093L3 10.271C2.625 10.5207 2.5 10.8953 2.5 11.2699V25.0043C2.5 27.1268 4.125 28.75 6.25 28.75H23.75C25.875 28.75 27.5 27.1268 27.5 25.0043V11.2699C27.5 10.8953 27.375 10.5207 27 10.271ZM17.5 16.2642V26.2528H12.5V16.2642H17.5ZM23.75 26.2528C24.5 26.2528 25 25.7534 25 25.0043V11.8942L15 4.15295L5 11.8942V25.0043C5 25.7534 5.5 26.2528 6.25 26.2528H10V15.0156C10 14.2665 10.5 13.767 11.25 13.767H18.75C19.5 13.767 20 14.2665 20 15.0156V26.2528H23.75Z" fill="white"/>
                            </mask>
                            <g mask="url(#mask0)">
                                <rect width="30" height="30" fill="#5E5873"/>
                            </g>
                        </svg>
                        <p class="main-text 2xl:text-lg lg:text-sm md:text-xs sm:text-xxs ml-2">
                            Dashboard
                        </p>
                    </div>
                            <div class="bg-white rounded-lg flex items-center py-3 px-4 mt-3">
                                <svg class="menu-icon" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M28.625 14.75L24.25 5C23.75 3.625 22.375 2.75 20.875 2.75H9.125C7.625 2.75 6.25 3.625 5.75 5L1.375 14.75C1.25 14.875 1.25 15.125 1.25 15.25V21.5C1.25 23.625 2.875 25.25 5 25.25H25C27.125 25.25 28.75 23.625 28.75 21.5V15.25C28.75 15.125 28.75 14.875 28.625 14.75ZM8.00002 5.99999C8.12502 5.49999 8.62502 5.24999 9.12502 5.24999H20.875C21.375 5.24999 21.875 5.49999 22 5.99999L25.5 14H20C19.625 14 19.25 14.25 19 14.5L16.875 17.75H13.25L11.125 14.5C10.75 14.25 10.375 14 10 14H4.37502L8.00002 5.99999ZM4.99998 22.75H25C25.75 22.75 26.25 22.25 26.25 21.5V16.5H20.625L18.5 19.75C18.25 20 17.875 20.25 17.5 20.25H12.5C12.125 20.25 11.75 20 11.5 19.75L9.37498 16.5H3.74998V21.5C3.74998 22.25 4.24998 22.75 4.99998 22.75Z" fill="#5E5873"/>
                                    <mask id="mask1" mask-type="alpha" maskUnits="userSpaceOnUse" x="1" y="2" width="28" height="24">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M28.625 14.75L24.25 5C23.75 3.625 22.375 2.75 20.875 2.75H9.125C7.625 2.75 6.25 3.625 5.75 5L1.375 14.75C1.25 14.875 1.25 15.125 1.25 15.25V21.5C1.25 23.625 2.875 25.25 5 25.25H25C27.125 25.25 28.75 23.625 28.75 21.5V15.25C28.75 15.125 28.75 14.875 28.625 14.75ZM8.00002 5.99999C8.12502 5.49999 8.62502 5.24999 9.12502 5.24999H20.875C21.375 5.24999 21.875 5.49999 22 5.99999L25.5 14H20C19.625 14 19.25 14.25 19 14.5L16.875 17.75H13.25L11.125 14.5C10.75 14.25 10.375 14 10 14H4.37502L8.00002 5.99999ZM4.99998 22.75H25C25.75 22.75 26.25 22.25 26.25 21.5V16.5H20.625L18.5 19.75C18.25 20 17.875 20.25 17.5 20.25H12.5C12.125 20.25 11.75 20 11.5 19.75L9.37498 16.5H3.74998V21.5C3.74998 22.25 4.24998 22.75 4.99998 22.75Z" fill="white"/>
                                    </mask>
                                    <g mask="url(#mask1)">
                                        <rect y="-1" width="30" height="30" fill="#5E5873"/>
                                    </g>
                                </svg>
                                <p class="main-text 2xl:text-lg lg:text-sm md:text-xs sm:text-xxs ml-2">
                                    Tokens
                                </p>
                            </div>
                            <inertia-link :href="route('company/list')">
                            <div class="bg-white rounded-lg flex items-center py-3 px-4 mt-3">
                                <svg class="menu-icon" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M25 7.5H21.25V6.25C21.25 4.125 19.625 2.5 17.5 2.5H12.5C10.375 2.5 8.75 4.125 8.75 6.25V7.5H5C2.875 7.5 1.25 9.125 1.25 11.25V23.75C1.25 25.875 2.875 27.5 5 27.5H25C27.125 27.5 28.75 25.875 28.75 23.75V11.25C28.75 9.125 27.125 7.5 25 7.5ZM11.25 6.25C11.25 5.5 11.75 5 12.5 5H17.5C18.25 5 18.75 5.5 18.75 6.25V7.5H11.25V6.25ZM18.75 25V10H11.25V25H18.75ZM3.75 23.75V11.25C3.75 10.5 4.25 10 5 10H8.75V25H5C4.25 25 3.75 24.5 3.75 23.75ZM25 25C25.75 25 26.25 24.5 26.25 23.75V11.25C26.25 10.5 25.75 10 25 10H21.25V25H25Z" fill="#5E5873"/>
                                    <mask id="mask2" mask-type="alpha" maskUnits="userSpaceOnUse" x="1" y="2" width="28" height="26">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M25 7.5H21.25V6.25C21.25 4.125 19.625 2.5 17.5 2.5H12.5C10.375 2.5 8.75 4.125 8.75 6.25V7.5H5C2.875 7.5 1.25 9.125 1.25 11.25V23.75C1.25 25.875 2.875 27.5 5 27.5H25C27.125 27.5 28.75 25.875 28.75 23.75V11.25C28.75 9.125 27.125 7.5 25 7.5ZM11.25 6.25C11.25 5.5 11.75 5 12.5 5H17.5C18.25 5 18.75 5.5 18.75 6.25V7.5H11.25V6.25ZM18.75 25V10H11.25V25H18.75ZM3.75 23.75V11.25C3.75 10.5 4.25 10 5 10H8.75V25H5C4.25 25 3.75 24.5 3.75 23.75ZM25 25C25.75 25 26.25 24.5 26.25 23.75V11.25C26.25 10.5 25.75 10 25 10H21.25V25H25Z" fill="white"/>
                                    </mask>
                                    <g mask="url(#mask2)">
                                        <rect width="30" height="30" fill="#5E5873"/>
                                    </g>
                                </svg>
                                <p class="main-text 2xl:text-lg lg:text-sm md:text-xs sm:text-xxs ml-2">
                                    Insurance Companies
                                </p>
                            </div>
                            </inertia-link>
                    </div>
                </div>
                <div class="col-span-3">
                    <div class="pt-8 px-6">
                    <nav class="rounded-xl bg-ins-2">
                        <!-- Primary Navigation Menu -->
                        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                            <div class="flex justify-end h-16">

                                <div class="hidden sm:flex sm:items-center sm:ml-6">
                                    <div class="ml-3 relative">
                                        <!-- Teams Dropdown -->
                                        <jet-dropdown align="right" width="60" v-if="$page.props.jetstream.hasTeamFeatures">
                                            <template #trigger>
                                        <span class="inline-flex rounded-md">
                                            <button type="button" class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 hover:bg-gray-50 hover:text-gray-700 focus:outline-none focus:bg-gray-50 active:bg-gray-50 transition">
                                                {{ $page.props.user.current_team.name }}

                                                <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                                    <path fill-rule="evenodd" d="M10 3a1 1 0 01.707.293l3 3a1 1 0 01-1.414 1.414L10 5.414 7.707 7.707a1 1 0 01-1.414-1.414l3-3A1 1 0 0110 3zm-3.707 9.293a1 1 0 011.414 0L10 14.586l2.293-2.293a1 1 0 011.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd" />
                                                </svg>
                                            </button>
                                        </span>
                                            </template>

                                            <template #content>
                                                <div class="w-60">
                                                    <!-- Team Management -->
                                                    <template v-if="$page.props.jetstream.hasTeamFeatures">
                                                        <div class="block px-4 py-2 text-xs text-gray-400">
                                                            Manage Team
                                                        </div>

                                                        <!-- Team Settings -->
                                                        <jet-dropdown-link :href="route('teams.show', $page.props.user.current_team)">
                                                            Team Settings
                                                        </jet-dropdown-link>

                                                        <jet-dropdown-link :href="route('teams.create')" v-if="$page.props.jetstream.canCreateTeams">
                                                            Create New Team
                                                        </jet-dropdown-link>

                                                        <div class="border-t border-gray-100"></div>

                                                        <!-- Team Switcher -->
                                                        <div class="block px-4 py-2 text-xs text-gray-400">
                                                            Switch Teams
                                                        </div>

                                                        <template v-for="team in $page.props.user.all_teams" :key="team.id">
                                                            <form @submit.prevent="switchToTeam(team)">
                                                                <jet-dropdown-link as="button">
                                                                    <div class="flex items-center">
                                                                        <svg v-if="team.id == $page.props.user.current_team_id" class="mr-2 h-5 w-5 text-green-400" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                                                        <div>{{ team.name }}</div>
                                                                    </div>
                                                                </jet-dropdown-link>
                                                            </form>
                                                        </template>
                                                    </template>
                                                </div>
                                            </template>
                                        </jet-dropdown>
                                    </div>

                                    <!-- Settings Dropdown -->
                                    <div class="ml-3 relative">
                                        <jet-dropdown align="right" width="48">
                                            <template #trigger>
                                                <button v-if="$page.props.jetstream.managesProfilePhotos" class="flex text-sm border-2 border-transparent rounded-full focus:outline-none focus:border-gray-300 transition">
                                                    <img class="h-8 w-8 rounded-full object-cover" :src="$page.props.user.profile_photo_url" :alt="$page.props.user.name" />
                                                </button>

                                                <span v-else class="inline-flex rounded-md">
                                            <button type="button" class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 hover:text-gray-700 focus:outline-none transition">
                                                <div>
                                                    <p class="2xl:text-base lg:text-sm md:text-xs sm:text-xxs main-text text-right mb-1">{{ $page.props.user.name }}</p>
                                                    <p class="2xl:text-xs main-text-2 text-right">Admin</p>
                                                </div>
                                                <img class="w-11 h-11 ml-3 rounded-full" src="images/bg1.jpg" alt="">
                                            </button>
                                        </span>
                                            </template>

                                            <template #content>
                                                <!-- Account Management -->
                                                <div class="block px-4 py-2 text-xs text-gray-400">
                                                    Manage Account
                                                </div>

                                                <jet-dropdown-link :href="route('profile.show')">
                                                    Profile
                                                </jet-dropdown-link>

                                                <jet-dropdown-link :href="route('api-tokens.index')" v-if="$page.props.jetstream.hasApiFeatures">
                                                    API Tokens
                                                </jet-dropdown-link>

                                                <div class="border-t border-gray-100"></div>

                                                <!-- Authentication -->
                                                <form @submit.prevent="logout">
                                                    <jet-dropdown-link as="button">
                                                        Log Out
                                                    </jet-dropdown-link>
                                                </form>
                                            </template>
                                        </jet-dropdown>
                                    </div>
                                </div>

                                <!-- Hamburger -->
                                <div class="-mr-2 flex items-center sm:hidden">
                                    <button @click="showingNavigationDropdown = ! showingNavigationDropdown" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 focus:text-gray-500 transition">
                                        <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                                            <path :class="{'hidden': showingNavigationDropdown, 'inline-flex': ! showingNavigationDropdown }" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                                            <path :class="{'hidden': ! showingNavigationDropdown, 'inline-flex': showingNavigationDropdown }" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Responsive Navigation Menu -->
                        <div :class="{'block': showingNavigationDropdown, 'hidden': ! showingNavigationDropdown}" class="sm:hidden">
                            <div class="pt-2 pb-3 space-y-1">
                                <jet-responsive-nav-link :href="route('dashboard')" :active="route().current('dashboard')">
                                    Dashboard
                                </jet-responsive-nav-link>
                            </div>

                            <!-- Responsive Settings Options -->
                            <div class="pt-4 pb-1 border-t border-gray-200">
                                <div class="flex items-center px-4">
                                    <div v-if="$page.props.jetstream.managesProfilePhotos" class="flex-shrink-0 mr-3" >
                                        <img class="h-10 w-10 rounded-full object-cover" :src="$page.props.user.profile_photo_url" :alt="$page.props.user.name" />
                                    </div>

                                    <div>
                                        <div class="font-medium text-base text-gray-800">{{ $page.props.user.name }}</div>
                                        <div class="font-medium text-sm text-gray-500">{{ $page.props.user.email }}</div>
                                    </div>
                                </div>

                                <div class="mt-3 space-y-1">
                                    <jet-responsive-nav-link :href="route('profile.show')" :active="route().current('profile.show')">
                                        Profile
                                    </jet-responsive-nav-link>

                                    <jet-responsive-nav-link :href="route('api-tokens.index')" :active="route().current('api-tokens.index')" v-if="$page.props.jetstream.hasApiFeatures">
                                        API Tokens
                                    </jet-responsive-nav-link>

                                    <!-- Authentication -->
                                    <form method="POST" @submit.prevent="logout">
                                        <jet-responsive-nav-link as="button">
                                            Log Out
                                        </jet-responsive-nav-link>
                                    </form>

                                    <!-- Team Management -->
                                    <template v-if="$page.props.jetstream.hasTeamFeatures">
                                        <div class="border-t border-gray-200"></div>

                                        <div class="block px-4 py-2 text-xs text-gray-400">
                                            Manage Team
                                        </div>

                                        <!-- Team Settings -->
                                        <jet-responsive-nav-link :href="route('teams.show', $page.props.user.current_team)" :active="route().current('teams.show')">
                                            Team Settings
                                        </jet-responsive-nav-link>

                                        <jet-responsive-nav-link :href="route('teams.create')" :active="route().current('teams.create')" v-if="$page.props.jetstream.canCreateTeams">
                                            Create New Team
                                        </jet-responsive-nav-link>

                                        <div class="border-t border-gray-200"></div>

                                        <!-- Team Switcher -->
                                        <div class="block px-4 py-2 text-xs text-gray-400">
                                            Switch Teams
                                        </div>

                                        <template v-for="team in $page.props.user.all_teams" :key="team.id">
                                            <form @submit.prevent="switchToTeam(team)">
                                                <jet-responsive-nav-link as="button">
                                                    <div class="flex items-center">
                                                        <svg v-if="team.id == $page.props.user.current_team_id" class="mr-2 h-5 w-5 text-green-400" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                                        <div>{{ team.name }}</div>
                                                    </div>
                                                </jet-responsive-nav-link>
                                            </form>
                                        </template>
                                    </template>
                                </div>
                            </div>
                        </div>
                    </nav>
                    </div>
                    <main class="px-6 overflow-y-auto" style="">
                        <slot></slot>
                    </main>
                </div>
            </div>

            <!-- Page Heading -->
            <!--<header class="bg-white shadow" v-if="$slots.header">-->
                <!--<div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">-->
                    <!--<slot name="header"></slot>-->
                <!--</div>-->
            <!--</header>-->

            <!-- Page Content -->

        </div>
    </div>
</template>

<script>
    import JetApplicationMark from '@/Jetstream/ApplicationMark'
    import JetBanner from '@/Jetstream/Banner'
    import JetDropdown from '@/Jetstream/Dropdown'
    import JetDropdownLink from '@/Jetstream/DropdownLink'
    import JetNavLink from '@/Jetstream/NavLink'
    import JetResponsiveNavLink from '@/Jetstream/ResponsiveNavLink'

    export default {
        components: {
            JetApplicationMark,
            JetBanner,
            JetDropdown,
            JetDropdownLink,
            JetNavLink,
            JetResponsiveNavLink,
        },

        data() {
            return {
                showingNavigationDropdown: false,
            }
        },

        methods: {
            switchToTeam(team) {
                this.$inertia.put(route('current-team.update'), {
                    'team_id': team.id
                }, {
                    preserveState: false
                })
            },

            logout() {
                this.$inertia.post(route('logout'));
            },
        }
    }
</script>
